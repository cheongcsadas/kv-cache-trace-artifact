"""Execute this experiment from native inference or collected observations."""
from experiments.chapter5.cli import main

if __name__ == "__main__":
    main("e11_profiling_cost")
